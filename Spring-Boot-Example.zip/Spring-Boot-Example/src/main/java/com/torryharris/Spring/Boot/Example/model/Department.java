package com.torryharris.Spring.Boot.Example.model;

import javax.persistence.*;

@Entity
@Table(name = "department")
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int did;
    private String dName;
    private String city;

    public Department(String dName,String city) {
        this.city = city;
        this.dName = dName;
    }

    public Department(){

    }
    public Department(int did, String dName, String city) {
        this.did = did;
        this.dName = dName;
        this.city = city;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public String getdName() {
        return dName;
    }

    public void setdName(String dName) {
        this.dName = dName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
