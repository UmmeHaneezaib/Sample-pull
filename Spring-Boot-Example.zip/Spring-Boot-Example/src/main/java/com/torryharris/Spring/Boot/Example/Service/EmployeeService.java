package com.torryharris.Spring.Boot.Example.Service;

import com.torryharris.Spring.Boot.Example.Exception.DepartmentNotFoundException;
import com.torryharris.Spring.Boot.Example.Exception.EmployeeAlreadyExistsException;
import com.torryharris.Spring.Boot.Example.Repository.DepartmentRepository;
import com.torryharris.Spring.Boot.Example.Repository.EmployeeRepository;
import com.torryharris.Spring.Boot.Example.model.Employee;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {
    private final Logger LOG = LoggerFactory.getLogger(this.getClass());
    @Autowired
    EmployeeRepository employeeRepository;
    @Autowired
    DepartmentRepository departmentRepository;

    public List<Employee> getAllEmployees() {
        System.out.println("getAllEmployees");
        return employeeRepository.findAll();
    }
    public List<Employee> getByEName(String eName){
        return employeeRepository.findByeName(eName);
    }

    public Employee getEmployeeById(int eid) {
        System.out.println("getEmployeeById");
        return employeeRepository.findById(eid).get();
    }
    public Employee addEmployee(Employee emp) {
        LOG.info("addEmployee");
        if (!employeeRepository.existsById(emp.getEid())) {
            if (emp.getDepartment() == null) {
                return employeeRepository.save(emp);
            } else if (departmentRepository.existsById(emp.getDepartment().getDid())) {
                return employeeRepository.save(emp);
            } else {
                throw new DepartmentNotFoundException();
            }
        } else {
            throw new EmployeeAlreadyExistsException();
        }
    }


//    public Employee addEmployee(Employee emp) {
//        LOG.info("addEmployee");
//        if (emp.getDepartment() != null) {
//            if (departmentRepository.existsById(emp.getDepartment().getDid())) {
//                LOG.info("employee added successfully.");
//                return employeeRepository.save(emp); // INSERT INTO ...
//            }
//        }
//        LOG.warn("employee was not added because given department if does not exist.");
//        return null;
//    }


    public Employee updateEmployee(Employee emp){

            return employeeRepository.save(emp);
        }
        public List<Employee> findBySalary(double salary){
        return employeeRepository.findBySalary(salary);
        }

//    public Employee deleteEmployee(int eid){
//        System.out.println("Delete Employees");
//        return employeeRepository.delete(eid);
//    }

}
