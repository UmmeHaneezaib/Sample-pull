package com.torryharris.Spring.Boot.Example.Repository;

import com.torryharris.Spring.Boot.Example.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {
    public abstract List<Employee> findByeName(String eName);
    public abstract List<Employee> findBySalaryGreaterThan(double salary);
    public abstract List<Employee> findBySalary(double salary);
    public abstract List<Employee> findBySalaryGreaterThanEqual(double salary);
    public abstract List<Employee> findByDepartment_City(String city);
}
