package com.torryharris.Spring.Boot.Example.demo;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.annotation.Configuration;
//
//public class SwaggerConfig {
//    @Configuration
//    @EnableSwagger2
//    public class SwaggerConfig {
//        public final Logger LOG = LoggerFactory.getLogger(this.getClass());
//
//        public Docket api(){
//            LOG.info("Swagger Initialization.....");
//            return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any()).paths(PathSelectors.any()).build();
//        }
//    }
//}
